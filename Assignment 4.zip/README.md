Assignment 4: Extending the Platform

This assignment includes the following starter files:

* __a4.py__: Use this file as the main module for your program.
* __OpenWeather.py__: Use this file as your module for the OpenWeather API.
* __LastFM.py__: Use this file as your module for the LastFM API.
* __WebAPI.py__: Use this file to implement common features for API modules.

If you plan on completing the extra credit, you will need to create a new module called __ExtraCreditAPI.py__.

Please visit the course website for a detailed overview of the assignment.
